/**
 * 
 */
/**
 * 
 */
module LoanManagementSystem {
	requires java.sql;
}