/**
 * 
 */
/**
 * 
 */
module DigitalAssetManagement {
	requires java.sql;
}