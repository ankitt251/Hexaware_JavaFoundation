/**
 * 
 */
/**
 * 
 */
module AssetManagement {
	requires java.sql;
}